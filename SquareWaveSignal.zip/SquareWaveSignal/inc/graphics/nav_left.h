#define nav_left_width 8
#define nav_left_height 5
static code const char nav_left_bits[] = {
  0x20, 0x40, 0x80, 0x40, 0x20};

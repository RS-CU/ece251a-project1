#define nav_down_width 8
#define nav_down_height 4
static code const char nav_down_bits[] = {
  0x00, 0x44, 0x28, 0x10};

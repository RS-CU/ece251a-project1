#define nav_up_width 8
#define nav_up_height 4
static code const char nav_up_bits[] = {
  0x10, 0x28, 0x44, 0x00};

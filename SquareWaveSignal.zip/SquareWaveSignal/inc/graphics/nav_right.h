#define nav_right_width 8
#define nav_right_height 5
static code const char nav_right_bits[] = {
  0x04, 0x02, 0x01, 0x02, 0x04};
